
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-10">
                                <h3>All posts Likes</h3>
                            </div> 
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Liked By</th>
                                    <th>Post By</th>
                                    <th>Post Details</th>
                                    <th>CreatedAt</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
    <script type="text/javascript">
        $(function() {

            var table = $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin.post.view_post_likes')); ?>",
                columns: [
                    {
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'liked_by',
                        name: 'liked_by'
                    },
                    {
                        data: 'post_by',
                        name: 'post_by'
                    },
                    {
                        data: 'post_details',
                        name: 'post_details'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                   
                ]
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Laravel projects\wasetak_dev\resources\views/Admin/post/like/index.blade.php ENDPATH**/ ?>