<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-10">
                            <h4>All Sub Category</h4>
                        </div>
                        <div class="col-2 d-flex justify-content-end">
                            <a href="<?php echo e(route('admin.subcategory.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i>
                                Create Sub Category</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                  
                        <br/>
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>    
                                    <th>Parent Ctegory</th>    
                                    <th>Description</th>    
                                    <th>Color</th>    
                                    <th>Status</th>    
                                    <th width="100px">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>

               
            </div>

        </div>
    </div>
</div>

<?php $__env->startSection('custom_scripts'); ?>

    <script type="text/javascript">

    $(function () {
      var table = $('.data-table').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo e(route('admin.subcategory.index')); ?>",
          columns: [
              {data: 'id', name: 'id'},
              {data: 'name', name: 'name'},
              {data: 'parent_category', name: 'parent_category'},
              {data: 'description', name: 'description'},
              {data: 'color', name: 'color'},
              {data: 'status', name: 'status'},
              {data: 'action', name: 'action', orderable: false, searchable: false},
          ]
      });
        
    });
  </script>
    
<?php $__env->stopSection(); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Laravel projects\wasetak_dev\resources\views/Admin/SubCategory/index.blade.php ENDPATH**/ ?>