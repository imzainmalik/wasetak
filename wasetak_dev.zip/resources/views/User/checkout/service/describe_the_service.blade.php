<div id="seller_describe_service_div" class="d-none">
   <div class="text-center mb-5">
      <h4>Please Describe The Service</h4>
      <p class="mb-0">Please explain briefly what is this service related to.</p>
   </div>
   <div class="row justify-content-center min_height">
      <div class="col-md-6">
          <textarea class="editor form-control" name="service_describe" id="service_describe"></textarea>
          
      </div>
      <div class="col-md-6" >
         <div class="h-100 input-preview" id="service_describe_preview_div">

         </div>
         
      </div>
   </div>
   <div class="text-center mt-5">
      <button class="button" id="btn_seller_describe_service" onclick="nextBackStepClickManage('seller_describe_service_div','seller_how_long_service_take_div')" disabled>Next</button>
      <button class="button light_button" onclick="nextBackStepClickManage('seller_describe_service_div','choose_item_or_service_type_div')">Back</button>
   </div>
</div>