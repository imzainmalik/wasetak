<h1>Welcome to WASETAK</h1>
   
 <p>Your account has been is created By Admin.<p>

    Name: {{ $request->name }} <br>
    Email: {{ $request->email }} <br>
    Password {{ $request->password }}

<br><br>
<h4>Thank you.</h4>

<h5><a href="https://wasetak.net/wasetak_dev/index">WASETAK.co</a></h5>
