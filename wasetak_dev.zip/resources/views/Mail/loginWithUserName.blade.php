<h1>Welcome to WASETAK</h1>

<p>Click the below link to access your account: <a href="{{$loginLink}}" class="btn" style="background-color: #F26D85; color: white;"> {{$loginLink}} </a> </p>