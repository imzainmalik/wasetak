<h1>Forget Password</h1>
   
<p>Somebody asked to reset your password on <a href="https://wasetak.net/wasetak_dev/index">WASETAK</a><p>
<p>It was not you, you can safely ignore this email.</p>

<p>Click the following reset password text to choose a new password.</p>
<a href="{{ route('reset.password.get', $token) }}">{{ route('reset.password.get', $token) }}</a>