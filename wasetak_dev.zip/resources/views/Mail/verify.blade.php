<h1>Welcome to WASETAK</h1>
   
<p>Before you can enjoy your new account, we will need you to confirm your email.<p>
<p>Click the following link to confirm and activate your new account:. <br><a href="{{ route('verification.verify', $token) }}">{{ route('verification.verify', $token) }}</a></p>
<p>If the above link is not clickable, try copying and pasting it into the address bar of your web browser.</p>
<p>If you’re experiencing problems, please contact support@wasetak.co.</p>

<br><br>
<h4>Thank you.</h4>
<h5><a href="https://wasetak.net/wasetak_dev/index">WASETAK.co</a></h5>
